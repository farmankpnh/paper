package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Restaurant;
import com.ltimindtree.serviceImplementation.RestaurantServiceImplementation;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {

	
	@Autowired
	private RestaurantServiceImplementation rstSerImpl;
	
	
	private Map<String, Object> response;
	
	//localhost:8081/restaurants/createRestaurants
	@PostMapping("/createRestaurants")
	 public ResponseEntity<Map<String, Object>> createRestaurant(@RequestBody Restaurant restaurent)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message","RESTAURANT ADDED SUCCESSFULLY...!");
		 response.put("status", HttpStatus.OK);
		 response.put("boby", rstSerImpl.createRestaurant(restaurent));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		 
	 }
	
	
	@GetMapping("/getRestaurantsByName/{name}")
	public ResponseEntity<Map<String, Object>> getRestaurantByName(@PathVariable String name)
	{
		response = new HashMap<String, Object>();
		response.put("message", "RESTAURANT FOUND BY NAME SUCCESSFULLY...!");
		response.put("status", HttpStatus.OK);
		response.put("body", rstSerImpl.getRestaurantByName(name));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	}
	
	
	 @GetMapping("/getRestaurantByLocation/{location}")
	 public ResponseEntity<Map<String , Object>> getRestaurantByLocation(@PathVariable String location)
	 {
		 response = new HashMap<String, Object>();
		 response.put("meaasge","RESTAURANTS FOUND BY LOCATION");
		 response.put("status",HttpStatus.OK);
		 response.put("body", rstSerImpl.getRestaurantByLocation(location));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	 }
	 
	 
	 @GetMapping("/getRestaurantByDistance/{distance}")
	 public ResponseEntity<Map<String, Object>> getRestaurantByDistance(@PathVariable int distance)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS FOUND BY DISTANCE");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstSerImpl.getRestaurantByDistance(distance));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		 
	 }

	 @GetMapping("/getRestaurantsByCuisine/{cuisine}")
	 public ResponseEntity<Map<String, Object>> getRestaurantByCuisine(@PathVariable String cuisine)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS FOUND BY CUISINE");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstSerImpl.getRestaurantByCuisine(cuisine));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		 
	 }
	 
	 @GetMapping("/getRestaurantsByBudget/{budget}")
	 public ResponseEntity<Map<String, Object>> getRestaurantByBudget(@PathVariable int budget)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS FOUND BY BUDGET");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstSerImpl.getRestaurantByBudget(budget));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		 
	 }
	 
	 @GetMapping("/getRestaurantsByRating/{rating}")
	 public ResponseEntity<Map<String, Object>> getRestaurantByRating(@PathVariable int rating)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS FOUND BY RATING");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstSerImpl.getRestaurantByRating(rating));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	 }
	 
}
