package com.ltimindtree.customerController;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.dto.CustomerEvent;
import com.ltimindtree.dto.Customers;
import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.serviceImplementation.CustomerServiceImplementation;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	private CustomerServiceImplementation custserImpl;
	//localhost:8083/customers/registerCustomer
	@PostMapping("/registerCustomer")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer)
	{
		return new ResponseEntity<Customer>(custserImpl.createCustomer(customer),HttpStatus.OK);
	}
	
	@DeleteMapping("/deactivateCustomerById/{custId}")
	public ResponseEntity<String > deactivateCustomer(@PathVariable int custId )
	{
		custserImpl.deactivateCustomer(custId);
		return new ResponseEntity<> ("Customer deactivated", HttpStatus.OK);
	}
	
	
	@PutMapping("/updateCustomer/{custId}")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer, @PathVariable(value="custId") int custId) throws CustomerNotFoundException
	{
		Customer updateCustomer = custserImpl.updateCustomer(customer, custId);
		if(updateCustomer == null)
		{
			return new ResponseEntity<Customer>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Customer>(updateCustomer, HttpStatus.OK);
	}
	
	//localhost:8083/customers/orders
	@PostMapping("/orders")

    public String placeOrder(@RequestBody Customers customers) {

      customers.setOrderId((UUID.randomUUID().toString()));  

        

        CustomerEvent customerEvent=new CustomerEvent();

        customerEvent.setStatus("Pending");

        customerEvent.setMessage("order status is in pending state");

        customerEvent.setCustomer(customers);

        return "Order Placed Successfully";

    }
	

}
