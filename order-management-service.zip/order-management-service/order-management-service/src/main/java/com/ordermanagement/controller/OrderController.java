package com.ordermanagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.dto.OrderRequestdto;
import com.ordermanagement.dto.OrderResponse;
import com.ordermanagement.exception.OrderNotFoundException;
import com.ordermanagement.model.Order;
import com.ordermanagement.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController {

	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	private OrderService orderService;

	//user can place order 
	@PostMapping("/placeorder")
	public ResponseEntity<?> addOrder(@RequestBody OrderRequestdto order) {
		logger.debug("In  addOrder controller method");

		OrderResponse responseOrder = orderService.saveorder(order);
		return new ResponseEntity<OrderResponse>(responseOrder, HttpStatus.ACCEPTED);

	}

	//user can update the order 
	@PutMapping("/update/id/{id}")
	public ResponseEntity<?> updateOrder(@RequestBody OrderRequestdto order, @PathVariable Long id)
			throws OrderNotFoundException {
		logger.debug("In  viewOrder updateOrder method");

		OrderResponse responseorder = orderService.updateOrderByID(id,order);
		return new ResponseEntity<OrderResponse>(responseorder, HttpStatus.ACCEPTED);
	}
	
	//user can cancel the order
	@DeleteMapping("/cancelorder/id/{id}")
	public ResponseEntity<?> cancleOrder(@PathVariable Long id) {
		
		String msg= orderService.cancleOrder(id);
		
		return new ResponseEntity<String>(msg, HttpStatus.OK);
	}
	
	//user can view the order 
	@GetMapping("/vieworder/id/{id}")
	public ResponseEntity<?> viewOrder(@PathVariable Long id) {
		logger.debug("In  viewOrder controller method");

		OrderResponse order = orderService.viewOrderByID(id);
		return new ResponseEntity<OrderResponse>(order, HttpStatus.OK);
	}
	
	//get order by restaurant id
	@GetMapping("/vieworderbyrestaurant/id/{id}")
	public ResponseEntity<?> viewOrderByRestaurantId(@PathVariable Long id) {
		logger.debug("In  viewOrder controller method");

		OrderResponse order = orderService.viewOrderByRestaurantId(id);
		return new ResponseEntity<OrderResponse>(order, HttpStatus.OK);
	}
	
	
	//get order by customer id
		@GetMapping("/vieworderbycustomer/id/{id}")
		public ResponseEntity<?> viewOrderByCustomerId(@PathVariable Long id) {
			logger.debug("In  viewOrder controller method");

			OrderResponse order = orderService.viewOrderByCustomerId(id);
			return new ResponseEntity<OrderResponse>(order, HttpStatus.OK);
		}
	
	


}
