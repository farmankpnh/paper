package com.ordermanagement.dto;

public class OrderResponse {
	private Long orderId;
	private Long customerId;
	private Long restaurantId;
	private double totalprice;
	
	public Long getOrderId() {
		return orderId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public Long getRestaurantId() {
		return restaurantId;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public OrderResponse(Long orderId, Long customerId, Long restaurantId, double totalprice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.restaurantId = restaurantId;
		this.totalprice = totalprice;
	}
	
	
	

}
