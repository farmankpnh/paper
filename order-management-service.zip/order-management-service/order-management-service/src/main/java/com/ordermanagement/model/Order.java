package com.ordermanagement.model;


import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private Long orderId;
	
	private Long customerId;
	private String status;
	private Long restaurantId;
	private double totalprice;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "Item_fid", nullable = false , referencedColumnName = "orderId")
	private List<OrderedItem> items;
	

	
	public Order( Long customerId, String status, Long restaurantId, double totalprice,
			List<OrderedItem> items) {
		super();
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		this.totalprice = totalprice;
		this.items = items;
	}
	
	public List<OrderedItem> getItems() {
		return items;
	}
	public void setItems(List<OrderedItem> items) {
		this.items = items;
	}
	public Order(Long id, Long customerId, String status, Long restaurantId) {
		super();
		this.orderId = id;
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
	}
	
	public Long getId() {
		return orderId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public String getStatus() {
		return status;
	}
	public Long getRestaurantId() {
		return restaurantId;
	}
	public void setId(Long id) {
		this.orderId = id;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}

	public double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}

	public Order() {
		super();
	}

	public Order(Long orderId, Long customerId, String status, Long restaurantId, double totalprice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		this.totalprice = totalprice;
	}

	public Order(Long customerId, String status, Long restaurantId) {
		super();
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		
	}
	
	

}
