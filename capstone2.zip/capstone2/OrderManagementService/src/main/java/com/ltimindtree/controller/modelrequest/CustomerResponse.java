package com.ltimindtree.controller.modelrequest;

import com.ltimindtree.entity.ItemDetail;

public class CustomerResponse {

	private String restaurantId;
	private ItemDetail itemDetail;
	private int totalPrice;
	private long orderTime;
	private String specialNote;
	private long deliveryTime;
	private String paymentId;
	private String customerName;
	private String customerCellNo;
	private String status;
	/**
	 * 
	 */
	public CustomerResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param restaurantId
	 * @param itemDetail
	 * @param totalPrice
	 * @param orderTime
	 * @param specialNote
	 * @param deliveryTime
	 * @param paymentId
	 * @param customerName
	 * @param customerCellNo
	 * @param status
	 */
	public CustomerResponse(String restaurantId, ItemDetail itemDetail, int totalPrice, long orderTime,
			String specialNote, long deliveryTime, String paymentId, String customerName, String customerCellNo,
			String status) {
		super();
		this.restaurantId = restaurantId;
		this.itemDetail = itemDetail;
		this.totalPrice = totalPrice;
		this.orderTime = orderTime;
		this.specialNote = specialNote;
		this.deliveryTime = deliveryTime;
		this.paymentId = paymentId;
		this.customerName = customerName;
		this.customerCellNo = customerCellNo;
		this.status = status;
	}
	/**
	 * @return the restaurantId
	 */
	public String getRestaurantId() {
		return restaurantId;
	}
	/**
	 * @param restaurantId the restaurantId to set
	 */
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	/**
	 * @return the itemDetail
	 */
	public ItemDetail getItemDetail() {
		return itemDetail;
	}
	/**
	 * @param itemDetail the itemDetail to set
	 */
	public void setItemDetail(ItemDetail itemDetail) {
		this.itemDetail = itemDetail;
	}
	/**
	 * @return the totalPrice
	 */
	public int getTotalPrice() {
		return totalPrice;
	}
	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	/**
	 * @return the orderTime
	 */
	public long getOrderTime() {
		return orderTime;
	}
	/**
	 * @param orderTime the orderTime to set
	 */
	public void setOrderTime(long orderTime) {
		this.orderTime = orderTime;
	}
	/**
	 * @return the specialNote
	 */
	public String getSpecialNote() {
		return specialNote;
	}
	/**
	 * @param specialNote the specialNote to set
	 */
	public void setSpecialNote(String specialNote) {
		this.specialNote = specialNote;
	}
	/**
	 * @return the deliveryTime
	 */
	public long getDeliveryTime() {
		return deliveryTime;
	}
	/**
	 * @param deliveryTime the deliveryTime to set
	 */
	public void setDeliveryTime(long deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	/**
	 * @return the paymentId
	 */
	public String getPaymentId() {
		return paymentId;
	}
	/**
	 * @param paymentId the paymentId to set
	 */
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the customerCellNo
	 */
	public String getCustomerCellNo() {
		return customerCellNo;
	}
	/**
	 * @param customerCellNo the customerCellNo to set
	 */
	public void setCustomerCellNo(String customerCellNo) {
		this.customerCellNo = customerCellNo;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
