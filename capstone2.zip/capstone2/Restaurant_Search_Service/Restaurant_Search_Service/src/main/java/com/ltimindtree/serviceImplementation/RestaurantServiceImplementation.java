package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.Restaurant;
import com.ltimindtree.repository.RestaurantRepository;
import com.ltimindtree.service.RestaurantService;


@Service
public class RestaurantServiceImplementation implements RestaurantService {

	@Autowired
	private RestaurantRepository restaurantRepository;
	
	
	@Override
	public Restaurant createRestaurant(Restaurant restaurent) {
		// TODO Auto-generated method stub
		return this.restaurantRepository.save(restaurent);
	}

	@Override
	public List<Restaurant> getRestaurantByName(String name) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByName(name);
		return restor;
	}

	@Override
	public List<Restaurant> getRestaurantByLocation(String location) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByLocation(location);
		return restor;
	}

	@Override
	public List<Restaurant> getRestaurantByDistance(int distance) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByDistance(distance);
		return restor;
	}

	@Override
	public List<Restaurant> getRestaurantByCuisine(String cuisine) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByCuisine(cuisine);
		return restor;
		
	}

	@Override
	public List<Restaurant> getRestaurantByBudget(int budget) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByBudget(budget);
		return restor;
	}

	@Override
	public List<Restaurant> getRestaurantByRating(int rating) {
		// TODO Auto-generated method stub
		List<Restaurant> restor = restaurantRepository.getRestaurantByRating(rating);
		return restor;
	}

}
