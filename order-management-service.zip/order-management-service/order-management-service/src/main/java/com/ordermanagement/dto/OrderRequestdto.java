package com.ordermanagement.dto;

import java.util.List;



public class OrderRequestdto {

	private Long customerId;
	private String status;
	private Long restaurantId;
	private double totalprice;
	
	private List<ItemRequestdto> requestedItems;
	
	
	
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public OrderRequestdto(Long customerId, String status, Long restaurantId, double totalprice,
			List<ItemRequestdto> requestedItems) {
		super();
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		this.totalprice = totalprice;
		this.requestedItems = requestedItems;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public String getStatus() {
		return status;
	}
	public Long getRestaurantId() {
		return restaurantId;
	}
	
	public List<ItemRequestdto> getRequestedItems() {
		return requestedItems;
	}
	
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}
	
	public void setRequestedItems(List<ItemRequestdto> requestedItems) {
		this.requestedItems = requestedItems;
	}
	public OrderRequestdto(Long orderId, Long customerId, String status, Long restaurantId,
			List<ItemRequestdto> requestedItems) {
		super();
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		this.requestedItems = requestedItems;
	}
	public OrderRequestdto() {
		super();
	}
	@Override
	public String toString() {
		return "OrderRequestdto [customerId=" + customerId + ", status=" + status + ", restaurantId=" + restaurantId
				+ ", totalprice=" + totalprice + ", requestedItems=" + requestedItems + "]";
	}
	
	
	

}
