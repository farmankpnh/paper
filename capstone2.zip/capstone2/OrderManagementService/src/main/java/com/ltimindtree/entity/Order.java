package com.ltimindtree.entity;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="orders")
public class Order {
	
	@Id
	private int id;
	
	@Column(unique = true, length = 100)
	private String orderId;
	@Column(unique = true, length = 100)
	private String restaurantId;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn
	private ItemDetail itemDetail;
	
	private int totalPrice;
	
	private long orderTime;
	
	private String specialNote;
	
	private long deliveryTime;
	@Column(unique = true, length = 100)
	private String paymentId;
	
	private String customerName;
	@Column(unique = true, length = 100)
	private String customerCellNo;
	
	private String status;
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}

	public ItemDetail getItemDetail() {
		return itemDetail;
	}

	public void setItemDetail(ItemDetail itemDetail) {
		this.itemDetail = itemDetail;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public long getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(long orderTime) {
		this.orderTime = orderTime;
	}

	public String getSpecialNote() {
		return specialNote;
	}

	public void setSpecialNote(String specialNote) {
		this.specialNote = specialNote;
	}

	public long getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(long deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCellNo() {
		return customerCellNo;
	}

	public void setCustomerCellNo(String customerCellNo) {
		this.customerCellNo = customerCellNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Order(int id, String orderId, String restaurantId, ItemDetail itemDetail, int totalPrice, long orderTime,
			String specialNote, long deliveryTime, String paymentId, String customerName, String customerCellNo,
			String status) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.restaurantId = restaurantId;
		this.itemDetail = itemDetail;
		this.totalPrice = totalPrice;
		this.orderTime = orderTime;
		this.specialNote = specialNote;
		this.deliveryTime = deliveryTime;
		this.paymentId = paymentId;
		this.customerName = customerName;
		this.customerCellNo = customerCellNo;
		this.status = status;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", orderId=" + orderId + ", restaurantId=" + restaurantId + ", itemDetail="
				+ itemDetail + ", totalPrice=" + totalPrice + ", orderTime=" + orderTime + ", specialNote="
				+ specialNote + ", deliveryTime=" + deliveryTime + ", paymentId=" + paymentId + ", customerName="
				+ customerName + ", customerCellNo=" + customerCellNo + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(customerCellNo, customerName, deliveryTime, id, itemDetail, orderId, orderTime, paymentId,
				restaurantId, specialNote, status, totalPrice);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return Objects.equals(customerCellNo, other.customerCellNo) && Objects.equals(customerName, other.customerName)
				&& deliveryTime == other.deliveryTime && id == other.id && Objects.equals(itemDetail, other.itemDetail)
				&& Objects.equals(orderId, other.orderId) && orderTime == other.orderTime
				&& Objects.equals(paymentId, other.paymentId) && Objects.equals(restaurantId, other.restaurantId)
				&& Objects.equals(specialNote, other.specialNote) && Objects.equals(status, other.status)
				&& totalPrice == other.totalPrice;
	}
	
	
	
	
	
	
	
	

}
