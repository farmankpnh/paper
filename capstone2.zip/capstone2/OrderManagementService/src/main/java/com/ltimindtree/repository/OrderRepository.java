package com.ltimindtree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltimindtree.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	List<Order> findByCustomerNameAndItemDetailName(String customerName, String name);
	List<Order> findByRestaurantId(String restaurantId);
	Order getByOrderIdAndCustomerName(String orderId, String customerName);
	List<Order> findByCustomerName(String customerName);
	List<Order> findByOrderId(String orderId);

	

	

}
