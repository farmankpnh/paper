package com.ordermanagement.exception;

public class OrderedItemBadRequestException  extends RuntimeException{
	
	public OrderedItemBadRequestException() {
		super();
	}
	
	public OrderedItemBadRequestException(String msg) {
		super(msg);
	}

}
