package com.ltimindtree.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="itemdetail")
public class ItemDetail {
	
	@Id
	@Column(unique = true, length = 100)
	private int id;
	
	private String name;
	
	private int price;
	
	private int quantity;
	/**
	 * 
	 */
	public ItemDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "ItemDetails [id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, name, price, quantity);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemDetail other = (ItemDetail) obj;
		return id == other.id && Objects.equals(name, other.name) && price == other.price && quantity == other.quantity;
	}
	/**
	 * @param id
	 * @param name
	 * @param price
	 * @param quantity
	 */
	public ItemDetail(int id, String name, int price, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}	
}
