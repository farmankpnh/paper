package com.ordermanagement.exception;

public class OrderNotFoundException extends RuntimeException {
	
	public OrderNotFoundException() {
		super();
	}
	public OrderNotFoundException(String msg) {
		super(msg);
	}

}
