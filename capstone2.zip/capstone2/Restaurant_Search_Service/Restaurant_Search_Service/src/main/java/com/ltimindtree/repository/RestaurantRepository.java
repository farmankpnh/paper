package com.ltimindtree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.ltimindtree.entity.Restaurant;


@EnableJpaRepositories
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer> {

	public List<Restaurant> getRestaurantByName(String name);

	public List<Restaurant> getRestaurantByLocation(String location);

	public List<Restaurant> getRestaurantByDistance(int distance);

	public List<Restaurant> getRestaurantByCuisine(String cuisine);

	public List<Restaurant> getRestaurantByBudget(int budget);
	
	public List<Restaurant> getRestaurantByRating( int rating);
}
