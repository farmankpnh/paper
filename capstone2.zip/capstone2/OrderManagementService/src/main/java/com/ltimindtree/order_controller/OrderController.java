package com.ltimindtree.order_controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.ServiceImplementation.OrderServiceImplementation;
import com.ltimindtree.controller.modelrequest.OrderCancelRequest;
import com.ltimindtree.controller.modelrequest.OrderRequest;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	private OrderServiceImplementation ordImpl;
	
	private Map<String, Object> response;
	
	//localhost:8082/orders/ordercreate
	@PostMapping("/ordercreate")
	public ResponseEntity<Map<String, Object>> createOrder(@RequestBody OrderRequest orderRequest, 
			@PathVariable String restaurantId)
	{
		response = new HashMap<String, Object>();
		response.put("message", "order create successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", ordImpl.createOrder(orderRequest));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	

	@PutMapping("/ordersUpdate")
	public ResponseEntity<Map<String, Object>> updateOrder(@RequestBody OrderRequest orderRequest) throws OrderException
	{
		response = new HashMap<String, Object>();
		response.put("message", "orders update successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", ordImpl.updateOrder(orderRequest));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		
		
	}
	
	
	@DeleteMapping("/ordrcancel")
	public ResponseEntity<Map<String, Object>> cancelOrder(@RequestBody OrderCancelRequest orderCancelRequest) throws OrderException
	{
		response = new HashMap<String, Object>();
		response.put("message", "orders cancelled successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", ordImpl.cancleOrder(orderCancelRequest));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		
		
	}
	
	
	@GetMapping("/orderView/{name}")
	public ResponseEntity<Map<String, Object>> viewOrders(@PathVariable String customerName) throws OrderException
	{
		response = new HashMap<String, Object>();
		response.put("message", "orders viewed successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", ordImpl.viewOrder(customerName));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getByOrderId/{orderId}")
	public ResponseEntity<Map<String, Object>> findByOrderId(@PathVariable String orderId)
	{
		response = new HashMap<String , Object>();
		response.put("message", "order viewed using orderID successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", ordImpl.findByOrderId(orderId));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	}
	
	
	@PostMapping("/createOrder")
//	public ResponseEntity<Map<String, Object>> createOrders(@RequestBody Order order)
//	{
//		response = new HashMap<String , Object>();
//		response.put("message", "orders created successfully");
//		response.put("status", HttpStatus.OK);
//		response.put("body", ordImpl.createOrders(order));
//		response.put("error", false);
//		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
//	}

//	public void createOrders(@RequestBody Order order)
//	{
//		ordImpl.createOrders(order);
//	}
	
	public ResponseEntity<Order> createOrders(@RequestBody Order order)
	{
		return new ResponseEntity<Order>(ordImpl.createOrders(order), HttpStatus.OK);
	}
	
	
	
//	public ResponseEntity<Map<String, Object>>deleteOrderById(@)
	
	@DeleteMapping("/deleteOrder/{id}")
	public ResponseEntity<String> deleteOrder(@PathVariable int id)
	{
		ordImpl.deleteOrder(id);
		return new ResponseEntity<>("Order deleted", HttpStatus.OK);
	}
	
}
