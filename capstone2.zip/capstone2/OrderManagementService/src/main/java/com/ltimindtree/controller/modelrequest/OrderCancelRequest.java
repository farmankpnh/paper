package com.ltimindtree.controller.modelrequest;

public class OrderCancelRequest {
	
	private String[] orderIds;
	private String customerName;
	/**
	 * @return the orderIds
	 */
	public String[] getOrderIds() {
		return orderIds;
	}
	/**
	 * @param orderIds the orderIds to set
	 */
	public void setOrderIds(String[] orderIds) {
		this.orderIds = orderIds;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	

}
