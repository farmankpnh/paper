package com.ltimindtree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltimindtree.entity.RestaurantMenu;

public interface RestaurantMenuRepository extends JpaRepository<RestaurantMenu, Integer> {

	public List<RestaurantMenu> findAllByRestaurantIdAndName(String restaurantId, String name);
	
	
	public List<RestaurantMenu> findByName(String name);
	

	
	public List<RestaurantMenu> findAllMenusByRestaurantId(String restaurantId);
	
}
