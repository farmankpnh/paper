package com.ordermanagement.service;

import com.ordermanagement.dto.OrderRequestdto;
import com.ordermanagement.dto.OrderResponse;
import com.ordermanagement.model.Order;

public interface OrderService {

	OrderResponse saveorder(OrderRequestdto order);

	OrderResponse viewOrderByID(Long id);

//	double getTotalAmount(Long id);

	OrderResponse updateOrderByID(Long id, OrderRequestdto order);

	String cancleOrder(Long id);

	OrderResponse viewOrderByRestaurantId(Long id);

	OrderResponse viewOrderByCustomerId(Long id);

}
