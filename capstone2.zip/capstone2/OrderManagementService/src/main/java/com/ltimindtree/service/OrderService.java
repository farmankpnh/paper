package com.ltimindtree.service;

import java.util.List;

import com.ltimindtree.controller.modelrequest.OrderCancelRequest;
import com.ltimindtree.controller.modelrequest.OrderCancelResponse;
import com.ltimindtree.controller.modelrequest.OrderRequest;
import com.ltimindtree.controller.modelrequest.OrderResponse;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;

public interface OrderService {
	
	OrderResponse createOrder(OrderRequest orderRequest);
	public OrderResponse updateOrder(OrderRequest orderRequest) throws OrderException;
	public OrderCancelResponse cancleOrder(OrderCancelRequest orderCancleRequest) throws OrderException;
	public List<Order> viewOrder(String customerName) throws OrderException;
	public List<Order> findByOrderId(String orderId);

	public Order createOrders(Order order);

	public void deleteOrder(int id);
	 
	
	
}
