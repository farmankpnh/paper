package com.ltimindtree.service;

import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;

public interface ReviewService {

	public Review CreateReview(Review review);
	public Review updateReview(Review review, int id) throws ReviewNotFoundException;

	public Review getReviewById(int id) throws ReviewNotFoundException;
	
}
