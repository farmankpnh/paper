package com.ordermanagement.exception;

public class OrderNotSavedException extends RuntimeException {
	public OrderNotSavedException() {
		super();
	}
	public OrderNotSavedException(String msg) {
		super(msg);
	}

}
