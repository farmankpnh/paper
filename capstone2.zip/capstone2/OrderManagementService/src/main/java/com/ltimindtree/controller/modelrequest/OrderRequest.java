package com.ltimindtree.controller.modelrequest;

import com.ltimindtree.entity.ItemDetail;

public class OrderRequest {

	
	private String transactionId;
	private String restaurantId;
	private ItemDetail itemDetail;
	private int totalPrice;
	private long orderTime;
	private String specialNote;
	private long deliveryTime;
	private String paymentId;
	private String customerName;
	private String customerCellNo;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the restaurantId
	 */
	public String getRestaurantId() {
		return restaurantId;
	}
	/**
	 * @param restaurantId the restaurantId to set
	 */
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	/**
	 * @return the itemDetail
	 */
	public ItemDetail getItemDetail() {
		return itemDetail;
	}
	/**
	 * @param itemDetail the itemDetail to set
	 */
	public void setItemDetail(ItemDetail itemDetail) {
		this.itemDetail = itemDetail;
	}
	/**
	 * @return the toatlPrice
	 */
	public int getToatlPrice() {
		return totalPrice;
	}
	/**
	 * @param toatlPrice the toatlPrice to set
	 */
	public void setToatlPrice(int toatlPrice) {
		this.totalPrice = toatlPrice;
	}
	/**
	 * @return the orderTime
	 */
	public long getOrderTime() {
		return orderTime;
	}
	/**
	 * @param orderTime the orderTime to set
	 */
	public void setOrderTime(long orderTime) {
		this.orderTime = orderTime;
	}
	/**
	 * @return the specialNote
	 */
	public String getSpecialNote() {
		return specialNote;
	}
	/**
	 * @param specialNote the specialNote to set
	 */
	public void setSpecialNote(String specialNote) {
		this.specialNote = specialNote;
	}
	/**
	 * @return the deliveryTime
	 */
	public long getDeliveryTime() {
		return deliveryTime;
	}
	/**
	 * @param deliveryTime the deliveryTime to set
	 */
	public void setDeliveryTime(long deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	/**
	 * @return the paymentId
	 */
	public String getPaymentId() {
		return paymentId;
	}
	/**
	 * @param paymentId the paymentId to set
	 */
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the customerCellNo
	 */
	public String getCustomerCellNo() {
		return customerCellNo;
	}
	/**
	 * @param customerCellNo the customerCellNo to set
	 */
	public void setCustomerCellNo(String customerCellNo) {
		this.customerCellNo = customerCellNo;
	}
	
	
}
