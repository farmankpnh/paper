package com.ltimindtree.service;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;

public interface CustomerService {

	public Customer createCustomer(Customer customer);
	public void deactivateCustomer(int custId);
	public Customer updateCustomer(Customer customer, int custId) throws CustomerNotFoundException;
}
