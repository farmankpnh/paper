package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.RestaurantMenu;
import com.ltimindtree.serviceImplementation.RestaurantMenuServiceImplementation;

@RestController
@RequestMapping("/restaurantMenu")
public class RestaurantMenuController {
	
	@Autowired
	private RestaurantMenuServiceImplementation rstMenSerImp;
	
	 private Map<String, Object> response;
	 
	 @PostMapping("createRestaurantMenu")
	 public ResponseEntity<Map<String , Object>> createRestaurantMenu(@RequestBody RestaurantMenu restaurantMenu)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS MENU LIST ADDED SUCCESSFULLY");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstMenSerImp.createRestaurantMenu(restaurantMenu));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	 }
	 
	 @GetMapping("findAllMenuByRestaurantId/{restaurantId}")
	 public ResponseEntity<Map<String, Object>> findAllMenusByRestaurantId(@PathVariable String restaurentId)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANTS MENU LIST BY RESTAURANTId");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstMenSerImp.findAllMenusByRestaurantId(restaurentId));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	 }
	 
	 
	 @GetMapping("findAllMenusByRestaurantIdAndName/{restaurantId}/{name}")
	 public ResponseEntity<Map<String, Object>> findAllByRestaurantIdAndName(@PathVariable String restaurentId, @PathVariable String name)
	 {
		 response = new HashMap<String, Object>();
		 response.put("message", "RESTAURANT MENU LIST BY RESTAURANTId AND NAME");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstMenSerImp.findAllByRestaurantIdAndName(restaurentId, name));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	 }
	 
	 @GetMapping("findByName/{name}")
	 public ResponseEntity<Map<String, Object>> findByName(@PathVariable String name)
	 {
		 response = new HashMap<String , Object>();
		 response.put("message", "RESTAURANTS MENU LIST BY NAME");
		 response.put("status", HttpStatus.OK);
		 response.put("body", rstMenSerImp.findByName(name));
		 response.put("error", false);
		 return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	 }


}
