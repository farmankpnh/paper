package com.ltimindtree.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author M1091009
 *
 */
@Entity
public class Restaurant {
	
	@Id
	private String id;
	private String restaurantId;
	private String name;
	private String location;
	int distance;
	String cuisine;
	int budget;
	int rating;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getName() {
		return name;
	}
	public void setRestaurantName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public int getBudget() {
		return budget;
	}
	public void setBudget(int budget) {
		this.budget = budget;
	}
	public int getRating()
	{
		return rating;
	}
	public void setRating(int rating)
	{
		this.rating = rating;
	}
	
public Restaurant(String id, String restaurantId, String name, String location, int distance, String cuisine,
		int budget, int rating) {
	super();
	this.id = id;
	this.restaurantId = restaurantId;
	this.name = name;
	this.location = location;
	this.distance = distance;
	this.cuisine = cuisine;
	this.budget = budget;
	this.rating = rating;
}


public Restaurant() {
	super();
	// TODO Auto-generated constructor stub
}


	
}
	
	
	
	
	