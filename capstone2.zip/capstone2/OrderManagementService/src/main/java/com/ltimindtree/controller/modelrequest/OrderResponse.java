package com.ltimindtree.controller.modelrequest;

import java.util.UUID;

public class OrderResponse {
	
	private String transactionId;
	private String orderId=UUID.randomUUID().toString();
	private String status;
	private String restaurantId;
	/**
	 * 
	 */
	public OrderResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param transactionId
	 * @param orderId
	 * @param status
	 * @param restaurantId
	 */
	public OrderResponse(String transactionId, String orderId, String status, String restaurantId) {
		super();
		this.transactionId = transactionId;
		this.orderId = orderId;
		this.status = status;
		this.restaurantId = restaurantId;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the restaurantId
	 */
	public String getRestaurantId() {
		return restaurantId;
	}
	/**
	 * @param restaurantId the restaurantId to set
	 */
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	
	

}
