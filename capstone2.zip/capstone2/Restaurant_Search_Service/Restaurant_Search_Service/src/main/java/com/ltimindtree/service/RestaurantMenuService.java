package com.ltimindtree.service;

import java.util.List;

import com.ltimindtree.entity.RestaurantMenu;

public interface RestaurantMenuService {

	public List<RestaurantMenu> findAllByRestaurantIdAndName(String restaurentID, String name);
	
	public List<RestaurantMenu> findByName(String name);
	
	public RestaurantMenu createRestaurantMenu(RestaurantMenu restMenu);
	
	List<RestaurantMenu> findAllMenusByRestaurantId(String restaurentId);

	
	
}
