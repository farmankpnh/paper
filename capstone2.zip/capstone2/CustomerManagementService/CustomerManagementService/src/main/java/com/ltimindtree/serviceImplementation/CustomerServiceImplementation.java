package com.ltimindtree.serviceImplementation;

import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.stereotype.Service;

import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.ltimindtree.dto.CustomerEvent;
import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.repository.CustomerRepository;
import com.ltimindtree.service.CustomerService;

@Service
public class CustomerServiceImplementation implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer custo = customerRepository.save(customer);
		return custo;
		
	}

	@Override
	public void deactivateCustomer(int custId) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(custId);
	}

	@Override
	public Customer updateCustomer(Customer customer, int custId) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
	
		Customer existingCustomer = customerRepository.findById(custId).orElseThrow(() -> new CustomerNotFoundException("customer", "custId", custId));
		existingCustomer.setName(customer.getName());
		existingCustomer.setGmail(customer.getGmail());
		existingCustomer.setCellNo(customer.getCellNo());
		existingCustomer.setPassword(customer.getPassword());
		customerRepository.save(existingCustomer);
		return existingCustomer;
	}
	
	
private static final Logger logger= LoggerFactory.getLogger(CustomerServiceImplementation.class);

    

    @Autowired

    private NewTopic topic;

     

    @Autowired

    private KafkaTemplate<String, CustomerEvent> kafkaTemplate;

 

   
    

    public void sendMessage(CustomerEvent event) {

        logger.info(String.format("Order even => %s", event.toString()));

        

        //create message

        Message<CustomerEvent> message=MessageBuilder.withPayload(event).setHeader(KafkaHeaders.TOPIC, topic.name()).build();

        kafkaTemplate.send(message);

    }
	
	

}
