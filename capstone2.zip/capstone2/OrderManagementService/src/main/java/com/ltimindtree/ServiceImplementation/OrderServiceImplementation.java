package com.ltimindtree.ServiceImplementation;

import java.util.List;
import java.util.UUID;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.controller.modelrequest.OrderCancelRequest;
import com.ltimindtree.controller.modelrequest.OrderCancelResponse;
import com.ltimindtree.controller.modelrequest.OrderRequest;
import com.ltimindtree.controller.modelrequest.OrderResponse;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;
import com.ltimindtree.repository.OrderRepository;
import com.ltimindtree.service.OrderService;

@Service
public class OrderServiceImplementation implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Override
	public OrderResponse createOrder(OrderRequest orderRequest) {
		// TODO Auto-generated method stub
		List<Order> orders = orderRepository.findByCustomerNameAndItemDetailName(orderRequest.getCustomerName()
				, orderRequest.getItemDetail().getName());
		OrderResponse orderResponse = null;
		if(orders!=null && orders.size()==0)
		{
			orderRequest.setTransactionId(UUID.randomUUID().toString());
			
			orderRequest.setToatlPrice(orderRequest.getItemDetail().getPrice() * orderRequest.getItemDetail().getQuantity());
			orderRequest.setOrderTime(System.currentTimeMillis());
			orderRequest.setDeliveryTime(System.currentTimeMillis()+300000);
			orderRequest.setPaymentId(orderRequest.getCustomerCellNo()+"_ORG");
			orderResponse = new OrderResponse();
			Order order = new Order();
			
			BeanUtils.copyProperties(orderRequest, order);
			order.setStatus("NEW");
			orderRepository.save(order);
			orderResponse.setRestaurantId(order.getRestaurantId());
			orderResponse.setOrderId(order.getOrderId());
			orderResponse.setTransactionId(UUID.randomUUID().toString());
			
		}
		return orderResponse;
	}

	@Override
	public OrderResponse updateOrder(OrderRequest orderRequest) throws OrderException {
		// TODO Auto-generated method stub
		OrderResponse orderResponse = null;
		List<Order> ordersForRestaurantId= orderRepository.findByRestaurantId(orderRequest.getRestaurantId());
				if(ordersForRestaurantId != null && ordersForRestaurantId.size()==0)
					throw new OrderException("order for updating not found");
		
		List<Order> orderForCustomerNameAndItem = orderRepository.findByCustomerNameAndItemDetailName(orderRequest.getCustomerName(), orderRequest.getItemDetail().getName());
		
		if(orderForCustomerNameAndItem !=null && orderForCustomerNameAndItem.size()==0) throw new OrderException("order not found");
		
		if(orderForCustomerNameAndItem !=null && orderForCustomerNameAndItem.size()==1)

		{
			orderRequest.setTransactionId(UUID.randomUUID().toString());
			orderRequest.setToatlPrice(orderRequest.getItemDetail().getPrice() * orderRequest.getItemDetail().getQuantity());
			orderRequest.setPaymentId(orderRequest.getCustomerCellNo()+"_REVISED");
			
		}else throw new OrderException("Order not update");
		return orderResponse;
	}

	@Override
	public OrderCancelResponse cancleOrder(OrderCancelRequest orderCancleRequest) throws OrderException {
		// TODO Auto-generated method stub
		String orderID= null;
		Order order = orderRepository.getByOrderIdAndCustomerName(orderID, orderCancleRequest.getCustomerName());
		if(order==null) throw new OrderException("Cancelling order");
		OrderCancelResponse res= new OrderCancelResponse();
		res.setTransactionId(UUID.randomUUID().toString());
		return res;
	}

	@Override
	public List<Order> viewOrder(String customerName) throws OrderException {
		// TODO Auto-generated method stub
		List<Order> orders= orderRepository.findByCustomerName(customerName);
		if(orders !=null && orders.size()==0) throw new OrderException("error");
		return orders;
	}

	@Override
	public List<Order> findByOrderId(String orderId) {
		// TODO Auto-generated method stub
		List<Order> ord = orderRepository.findByOrderId(orderId);
		return ord;
	}

	@Override
	public Order createOrders(Order order) {
		// TODO Auto-generated method stub
//		return this.orderRepository.save(order);
		
		Order ord = orderRepository.save(order);
		return ord;
	}

	@Override
	public void deleteOrder(int id) {
		// TODO Auto-generated method stub
	orderRepository.deleteById(id);	
	}

	




	
	
	
}
