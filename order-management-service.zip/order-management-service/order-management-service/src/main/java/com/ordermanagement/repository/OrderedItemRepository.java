package com.ordermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ordermanagement.model.OrderedItem;

@Repository
public interface OrderedItemRepository extends JpaRepository<OrderedItem, Long> {

	@Query(value="FROM OrderedItem WHERE order_id = ?1",nativeQuery = true)
	List<OrderedItem> findbyOrderId(Long orderId);

}
