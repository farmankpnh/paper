package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;
import com.ltimindtree.serviceImplementation.ReviewServiceImplementation;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

	@Autowired
	private ReviewServiceImplementation revSerImpl;
	

	private Map<String, Object> response;
	
	//localhost:8086/reviews/createReview
	@PostMapping("/createReview")
	public ResponseEntity<Review > CreateReview(@RequestBody Review review)
	{
		return new ResponseEntity<Review>(revSerImpl.CreateReview(review),HttpStatus.OK);
	}
	
	@GetMapping("/viewReview/{id}")
	public ResponseEntity<Map<String, Object>> getReviewById(@PathVariable (value = "id") int id) throws ReviewNotFoundException
	{
		response = new HashMap<String, Object>();
		response.put("message", "Review provided successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", revSerImpl.getReviewById(id));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		
	}
	
	@PutMapping("/updateReview/{id}")
	public ResponseEntity<Map<String, Object>> updateReview(@RequestBody Review review, @PathVariable(value = "id")int id) throws ReviewNotFoundException
	{
		response = new HashMap<String, Object>();
		response.put("message", "Review updated successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", revSerImpl.updateReview(review, id));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
	}
	
}
