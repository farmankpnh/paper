package com.ordermanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ordermanagement.dto.ItemRequestdto;
import com.ordermanagement.dto.OrderRequestdto;
import com.ordermanagement.dto.OrderResponse;
import com.ordermanagement.exception.OrderNotFoundException;
import com.ordermanagement.exception.OrderNotSavedException;
import com.ordermanagement.exception.OrderedItemBadRequestException;
import com.ordermanagement.model.Order;
import com.ordermanagement.model.OrderedItem;
import com.ordermanagement.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Override
	public OrderResponse saveorder(OrderRequestdto orderRequest) throws OrderNotSavedException {
		logger.info("Inside saveorder  Service method"+orderRequest);

		List<OrderedItem> allItemsList = new ArrayList<>();
		List<ItemRequestdto> requesedItem = orderRequest.getRequestedItems();

		for (ItemRequestdto i : requesedItem) {
			allItemsList.add(new OrderedItem(i.getItemName(), i.getQuantity(), i.getPrice()));
		}
		double amount = 0;
	
		//logger.info(" updated amount :"+amount);
		for (OrderedItem o : allItemsList) {
			//logger.info("price"+o.getPrice() +"quantity"+ o.getQuantity());
			amount = amount + (o.getPrice() * o.getQuantity());
			//logger.info(" updated amount :"+amount);

		}

		Order getOrder = new Order(orderRequest.getCustomerId(), orderRequest.getStatus(),
				orderRequest.getRestaurantId(), amount, allItemsList);

		Order responseorder = orderRepository.save(getOrder);

		OrderResponse response = new OrderResponse(responseorder.getId(), responseorder.getCustomerId(),
				responseorder.getRestaurantId(), responseorder.getTotalprice());
		
		return response;
	}

	@Override
	public OrderResponse viewOrderByID(Long id)  {
		logger.debug("Inside viewOrderByID  Service method");
		Order responseorder = orderRepository.findById(id)
				.orElseThrow(() -> new OrderedItemBadRequestException("this Order is not placed"));
		
		OrderResponse response = new OrderResponse(responseorder.getId(), responseorder.getCustomerId(),
				responseorder.getRestaurantId(), responseorder.getTotalprice());
		
		return response;
	}



	@Override
	public String cancleOrder(Long id) {
		Order oldOrder = orderRepository.findById(id)
				.orElseThrow(() -> new OrderedItemBadRequestException("this Order is not placed"));

		orderRepository.delete(oldOrder);

		return "Order Deleted With Id : " + id;
	}

	@Override
	public OrderResponse updateOrderByID(Long id, OrderRequestdto orderRequest) {
		Order oldOrder = orderRepository.findById(id)
				.orElseThrow(() -> new OrderNotFoundException("this Order is not placed"));
		
		List<OrderedItem> allItemsList = new ArrayList<>();
		List<ItemRequestdto> requesedItem = orderRequest.getRequestedItems();

		for (ItemRequestdto i : requesedItem) {
			allItemsList.add(new OrderedItem(i.getItemName(), i.getQuantity(), i.getPrice()));
		}
		double amount = 0;
	
		//logger.info(" updated amount :"+amount);
		for (OrderedItem o : allItemsList) {
			//logger.info("price"+o.getPrice() +"quantity"+ o.getQuantity());
			amount = amount + (o.getPrice() * o.getQuantity());
			//logger.info(" updated amount :"+amount);

		}
		oldOrder.setCustomerId(orderRequest.getCustomerId());
		oldOrder.setRestaurantId(orderRequest.getRestaurantId());
		oldOrder.setStatus(orderRequest.getStatus());
		oldOrder.setTotalprice(amount);
		oldOrder.setItems(allItemsList);
		
		
		Order responseorder = orderRepository.save(oldOrder);

		OrderResponse response = new OrderResponse(responseorder.getId(), responseorder.getCustomerId(),
				responseorder.getRestaurantId(), responseorder.getTotalprice());
		
		return response;
	}

	
	@Override
	public OrderResponse viewOrderByRestaurantId(Long id) throws OrderNotFoundException{
		Order responseorder = orderRepository.findByRestaurantId(id);
		
		OrderResponse response = new OrderResponse(responseorder.getId(), responseorder.getCustomerId(),
				responseorder.getRestaurantId(), responseorder.getTotalprice());
		
		return response;
	}

	@Override
	public OrderResponse viewOrderByCustomerId(Long id) {
		Order responseorder = orderRepository.findByCustomerId(id);
		
		OrderResponse response = new OrderResponse(responseorder.getId(), responseorder.getCustomerId(),
				responseorder.getRestaurantId(), responseorder.getTotalprice());
		
		return response;
	}

}

