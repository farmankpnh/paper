package com.ltimindtree.serviceImplementation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.ltimindtree.dto.CustomerEvent;
import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;
import com.ltimindtree.repository.ReviewRepository;
import com.ltimindtree.service.ReviewService;


@Service
public class ReviewServiceImplementation implements ReviewService {

	@Autowired
	private ReviewRepository revRepository;
	
	@Override
	public Review CreateReview(Review review) {
		// TODO Auto-generated method stub
		return revRepository.save(review);
	}

	@Override
	public Review updateReview(Review review, int id) throws ReviewNotFoundException {
		// TODO Auto-generated method stub
		Review existingReview = revRepository.findById(id).orElseThrow(() -> new ReviewNotFoundException("Review", "Id", id));
		existingReview.setReview(review.getReview());
		existingReview.setRating(review.getRating());
		revRepository.save(existingReview);
		return existingReview;
		
	}

	@Override
	public Review getReviewById(int id) throws ReviewNotFoundException {
		// TODO Auto-generated method stub
		return revRepository.findById(id).orElseThrow(() -> new ReviewNotFoundException("Review", "Id", id) );
	}
	
	
private static final Logger logger=LoggerFactory.getLogger(ReviewServiceImplementation.class);

    

    @KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${sping.kafka.consumer.group-id}")

    public void consume(CustomerEvent event) {

        

        logger.info(String.format("Order event received in stock event=> %s", event.toString()));

        

        //save order event into database

      

        

        

        

        

    }

}
