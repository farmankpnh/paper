package com.ordermanagement.dto;

public class ItemRequestdto {
	
	private String itemName;
	private int quantity;
	private double price;
	
	
	public String getItemName() {
		return itemName;
	}
	public int getQuantity() {
		return quantity;
	}
	public double getPrice() {
		return price;
	}
	
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public ItemRequestdto(Long itemId, String itemName, int quantity, double price) {
		super();
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}
	@Override
	public String toString() {
		return "ItemRequestdto [itemName=" + itemName + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
	

}
