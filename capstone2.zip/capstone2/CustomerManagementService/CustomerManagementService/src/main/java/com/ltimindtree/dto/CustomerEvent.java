package com.ltimindtree.dto;

public class CustomerEvent {
	
	private String message;

    private String status;

    private Customers customer;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}

	public CustomerEvent(String message, String status, Customers customer) {
		super();
		this.message = message;
		this.status = status;
		this.customer = customer;
	}

	public CustomerEvent() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
