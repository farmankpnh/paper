package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.RestaurantMenu;
import com.ltimindtree.repository.RestaurantMenuRepository;
import com.ltimindtree.service.RestaurantMenuService;

@Service
public class RestaurantMenuServiceImplementation implements RestaurantMenuService {

	@Autowired
	private RestaurantMenuRepository rstMenuRepository;
	
	
	@Override
	public List<RestaurantMenu> findAllByRestaurantIdAndName(String restaurentID, String name) {
		// TODO Auto-generated method stub
		List<RestaurantMenu> rmenu = rstMenuRepository.findAllByRestaurantIdAndName(restaurentID, name);
		return rmenu;
	}

	@Override
	public List<RestaurantMenu> findByName(String name) {
		// TODO Auto-generated method stub
		List<RestaurantMenu> rmenu = rstMenuRepository.findByName(name);
		return rmenu;
	}

	@Override
	public RestaurantMenu createRestaurantMenu(RestaurantMenu restMenu) {
		// TODO Auto-generated method stub
	return rstMenuRepository.save(restMenu);
	}

	@Override
	public List<RestaurantMenu> findAllMenusByRestaurantId(String restaurentId) {
		// TODO Auto-generated method stub
	
		List<RestaurantMenu> rmenu = rstMenuRepository.findAllMenusByRestaurantId(restaurentId);
		return rmenu;
	}

}
